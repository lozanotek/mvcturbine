namespace MvcApplication
{
    using Mvc;
    
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    /// <summary>
    /// Plugin into the flow of the application.
    /// </summary>
    public class MvcApplication : DefaultMvcApplication
    {
    }
}