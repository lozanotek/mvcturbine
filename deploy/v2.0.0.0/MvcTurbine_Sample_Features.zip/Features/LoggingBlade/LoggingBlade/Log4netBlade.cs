﻿namespace MvcTurbine.Samples.LoggingBlade {
    using System;
    using System.IO;
    using Blades;
    using Impl;
    using log4net.Config;

    public class Log4netBlade : Blade {
        public override void Spin(IRotorContext context) {
            // Register the log4net implementation of the logger
            RegisterServices(context);

            // Setup log4net
            SetupLogging();
        }

        private static void RegisterServices(IRotorContext context) {
            // This can live within a IServiceRegistration, but I opted to put here
            // to keep the codebase small
            context.ServiceLocator.Register<ILogger, Logger>();
        }

        private static void SetupLogging() {
            // Get the path to the file
            string path = AppDomain.CurrentDomain.BaseDirectory;
            string filePath = Path.Combine(path, "log4net.config");

            var fileInfo = new FileInfo(filePath);
            if (fileInfo.Exists) {
                // Get the info from the file
                XmlConfigurator.ConfigureAndWatch(fileInfo);
            }
            else {
                // Look at the web.config for the info
                XmlConfigurator.Configure();
            }
        }
    }
}