﻿namespace MvcTurbine.Samples.ExtensionMethods.Services {
    public interface IMessageService {
        string GetWelcomeMessage();
        string GetAboutMessage();
        string GetContent();
    }
}