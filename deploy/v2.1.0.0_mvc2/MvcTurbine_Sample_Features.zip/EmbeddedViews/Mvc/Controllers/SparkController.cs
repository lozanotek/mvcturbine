﻿namespace Mvc.Controllers {
    using System.Web.Mvc;

    public class SparkController : Controller {
    }
}