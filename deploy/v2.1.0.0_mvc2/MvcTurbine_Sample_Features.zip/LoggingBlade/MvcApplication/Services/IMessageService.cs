﻿namespace MvcTurbine.Samples.LoggingBlade.Web.Services {
    public interface IMessageService {
        string GetWelcomeMessage();
        string GetAboutMessage();
    }
}