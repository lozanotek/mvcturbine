﻿namespace Mvc.Services
{
    public interface IMessageService
    {
        string GetWelcomeMessage();
    }
}
