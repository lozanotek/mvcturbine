﻿using System.Web.Mvc;

namespace NerdDinner.Controllers {
    [HandleErrorWithELMAH]
    public class HomeController : Controller {
    }
}