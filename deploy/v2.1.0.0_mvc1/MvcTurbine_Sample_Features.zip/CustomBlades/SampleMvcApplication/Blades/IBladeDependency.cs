namespace MvcTurbine.Samples.CustomBlades.Blades {
    public interface IBladeDependency {
        void DoWork();
    }
}