﻿namespace MvcTurbine.Samples.ControllerInjection.Services {
    public interface IMessageService {
        string GetWelcomeMessage();
        string GetAboutMessage();
    }
}