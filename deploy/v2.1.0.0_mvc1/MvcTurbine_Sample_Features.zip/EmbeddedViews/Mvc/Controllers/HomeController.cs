namespace Mvc.Controllers {
    using System.Web.Mvc;

    public class HomeController : Controller {
    }
}