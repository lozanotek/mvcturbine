namespace Mvc.Controllers {
    using System.Web.Mvc;

    public class WebFormController : Controller {
    }
}