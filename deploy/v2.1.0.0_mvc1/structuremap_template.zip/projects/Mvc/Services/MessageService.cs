﻿namespace Mvc.Services
{
    public class MessageService : IMessageService
    {
        public string GetWelcomeMessage()
        {
            return "Welcome to ASP.NET MVC!";
        }
    }
}
